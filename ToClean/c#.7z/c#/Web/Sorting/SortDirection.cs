﻿using System;
namespace Mvc.Helper.Sorting
{
	[Serializable]
	public enum SortDirection
	{
		Ascending, 
		Descending
	}
}